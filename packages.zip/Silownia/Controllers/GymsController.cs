﻿using Silownia.Models;
using Silownia.Models.DbModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Silownia.Controllers
{
    public class GymsController : Controller
    {
        // GET: Gyms
        public ActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public ActionResult Create()
        {
            return View(new Gym());
        }
        /*[HttpPost]
        public ActionResult Create(Gym gym)
        {
            if(ModelState.IsValid)
            {
                using(DatabaseContext db = new DatabaseContext())
                {
                    db.Gyms.Add(gym);
                    db.SaveChanges();
                }
                return RedirectToAction("Index");
            }
            return View(new Gym());
        }*/
    }
}